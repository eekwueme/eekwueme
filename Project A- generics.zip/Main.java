class Main{
    public static void main(String[] args) {
        Trio<Integer> t = new Trio<>(4,6,8);
        System.out.println("t "+t);
        System.out.println("Has duplicates "+t.hasDuplicates());
        Trio<Integer> s = new Trio<>(6,8,4);
        System.out.println("s "+s);
        System.out.println("s==t "+s.equals(t));
        s.reset(5);
        System.out.println("S "+s);
        System.out.println("Has duplicates "+s.hasDuplicates());
        System.out.println("Count of 5 in s = "+s.count(5));
    }
}