import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//Trio class
class Trio<T>{
    //3 objects
    T a,b,c;
    Trio(T a, T b, T c){
        this.a = a;
        this.b = b;
        this.c = c;
    }
    Trio(T a){
        this.a = this.b = this.c = a;
    }
    //This method resets trio to given argument
    public void reset(T t){
        this.a = this.b = this.c = t;
    }

    //Count of given item in Trio
    public int count(T t){
        int c = 0;
        if(t.equals(this.a)){
            c++;
        }
        if(t.equals(this.b)){
            c++;
        }
        if(t.equals(this.c)){
            c++;
        }
        return c;
    }

    //Check if trio has duplicates
    public boolean hasDuplicates(){
        return this.a.equals(this.b) || this.b.equals(this.c) || this.c.equals(this.a);
    }

    @Override
    public boolean equals(Object obj){
        if(!(obj instanceof Trio)){
            return false;
        }
        Trio t = (Trio)obj;
        List<T> tl = new ArrayList();
        tl.add(a);
        tl.add(b);
        tl.add(c);
        List<T> al = new ArrayList();
        al.add((T)t.a);
        al.add((T)t.b);
        al.add((T)t.c);
        return tl.size()==al.size() && tl.containsAll(al);
    }

    @Override
    public String toString(){
        return "("+a+" "+b+" "+c+")";
    }
}